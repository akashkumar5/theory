</div>
<footer>
    <div class="copyright text-right">
        <i><strong><?php echo $copyright; ?> </strong></i>
    </div>
</footer>
</body>
</html>